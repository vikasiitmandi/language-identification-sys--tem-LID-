
This folder contains main.py, gmm.py and utils.py 

Install the following libraries:

csv (pip install python-csv)
librosa (pip install librosa)
numpy (pip install numpy)

Run only the main.py file for extracting MFCC features of audio files in .wav format, which will be saved (in .csv format) after voice activity detection.
